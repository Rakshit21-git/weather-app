
import './App.css';
import Firstcomponent from './components/Firstcomponent';


function App() {
  return (
    <div>
      
   <Firstcomponent></Firstcomponent>
      
    </div>
    
  )
}

export default App;
